from playsound import playsound
playsound('klickljud.wav')
print("hello")
input()
